function edges = orderEdges(edges)
%takes an Nx2 edge list and orders the line elements so that it starts with
%one and line elements are consecutive


edgesOut = zeros(size(edges));
connIdx = 1; % we are always starting with vertex #1

%% finding the first edge
containsVert = find((edges(:,1) == connIdx) | (edges(:,2) == connIdx));
ed = containsvert(1);

edgesOut(1,:) = edges(ed,:);
if ~(edgesOut(1,1) == 1)
    edgesOut(1,:) = fliplr(edgesOut(1,:));
end
edges(ed,:) = [];

connIdx = edgesOut(1,2);

%% connecting up the other edges
while ~isempty(edges)
    containsVert = (edges(:,1) == connIdx) | (edges(:,2) == connIdx);
    
    if sum(containsVert > 1)
        error('segmented line detected');
    end
    
    edgesOut(end+1,:) = edges(containsVert,:);
    if ~(edgesOut(end,1) == connIdx)
        edgesOut(end,:) = fliplr(edgesOut(end,:));
    end
    

end