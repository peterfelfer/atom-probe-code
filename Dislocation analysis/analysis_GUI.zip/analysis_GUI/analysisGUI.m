

%% Data variables:

% obj.vertices
% obj.objects{i}    
    % .type (p,l,f,c,v) c = compound v = volume
    % .vertices
    % .selection
        % .vertices
        % .analysis{}
            % .name
            % .type (enum in 'IEmap','proxigram','IEval','concShell','bulkConc')
            % .data
        
        
% .selection (for the selection listbox);
% .usedAtoms (from xrng file, for elements listbox)
    
% .xrng
% .posFile
% .posFileName (absolute path)


% .vertexList
% .slicedVAP
% .vertexArea (area per vertex, calculated using the prism approximation)

% .report (maybe)


% .clipDist (for prism approximation)

% .selectionDictionary (translates brushed verts back to object verts)



% .log (text string to be written, logging all actions)

%% to do list

% fix prism approximation 









function varargout = analysisGUI(varargin)
% ANALYSISGUI M-file for analysisGUI.fig
%      ANALYSISGUI, by itself, creates a new ANALYSISGUI or raises the existing
%      singleton*.
%
%      H = ANALYSISGUI returns the handle to a new ANALYSISGUI or the handle to
%      the existing singleton*.
%
%      ANALYSISGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANALYSISGUI.M with the given input arguments.
%
%      ANALYSISGUI('Property','Value',...) creates a new ANALYSISGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before analysisGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to analysisGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help analysisGUI

% Last Modified by GUIDE v2.5 19-Jan-2012 16:27:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @analysisGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @analysisGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before analysisGUI is made visible.
function analysisGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to analysisGUI (see VARARGIN)

% Choose default command line output for analysisGUI
handles.output = hObject;




%%initialize some variables

handles.clipDist = 0.5;


handles.obj.objects = [];
handles.obj.vertices =[];
    
handles.xrng = [];
handles.posFile = [];
handles.slicedVAP = [];









% Update handles structure
guidata(hObject, handles);

% UIWAIT makes analysisGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = analysisGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;







% --- Executes on button press in openPos.
function openPos_Callback(hObject, eventdata, handles)
% hObject    handle to openPos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[file path] = uigetfile('*.pos','Select a pos file');
fileName = [path file];
fid = fopen(fileName, 'r');

set(handles.messages,'String','reading *.pos file');

lflo=fread(fid, inf, '4*float32', 'b');
nb=length(lflo)/4;

set(handles.messages,'String',[num2str(nb) ' atomic positions loaded']);


pos=reshape(lflo, [4 nb]);
pos=pos';

pos = single(pos);


handles.posFile = pos;
handles.posFileName = fileName;

clear lflo pos

fclose(fid);




guidata(hObject,handles);











% --- Executes on button press in openObj.
function openObj_Callback(hObject, eventdata, handles)
% hObject    handle to openObj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[file path] = uigetfile('*.obj','import .obj');


obj = read_wobj_v2([path file]);


numobjectsObj = length(obj.objects);
numobjects = length(handles.obj.objects);

numverts = length(handles.obj.vertices);


handles.obj.vertices = [handles.obj.vertices; obj.vertices];



for i=1:numobjectsObj
    currentObj = numobjects+i;
    
    
    %try
        verts = obj.objects{i}.vertices;
        verts = verts + numverts;
    
        handles.obj.objects{currentObj}.vertices = verts;
        
       
    
        handles.obj.objects{currentObj}.type = obj.objects{i}.type;
        
        handles.obj.objects{currentObj}.selection{1}.name = 'all';
        handles.obj.objects{currentObj}.selection{1}.vertices = unique(verts);
        handles.obj.objects{currentObj}.selection{1}.analysis{1} = [];
        
    
        
    %catch
     %   set(handles.messages,'String','Wavefront object not recognized');
    %end
    
    
end


%update the object listbox
for i=1:length(handles.obj.objects)
    
    try
        switch handles.obj.objects{i}.type
        
            case 'p'
                tagStr = 'points '
                
            case 'l'
                tagStr = 'line '
                
            case 'f'
                tagStr = 'boundary '
                
            case 'pc'
                tagStr= 'point compound'
                
            case 'lc'
                tagStr = 'line compound'
                
            case 'fc' 
                tagStr = 'boundary compound'
                
        end
        
    end
    
    handles.objects{i} = [tagStr num2str(i)];
end
set(handles.analysisObjectsList,'String',handles.objects);

set(handles.analysisObjectsList,'Value',length(handles.obj.objects));



%update selection listbox
handles.selection = [];
currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);


for i=1:length(handles.obj.objects{currentObj}.selection)
    handles.selection{i} = handles.obj.objects{currentObj}.selection{i}.name;
end
set(handles.selectionObjectsList,'String',handles.selection);



guidata(hObject,handles);


redrawObjectAxis(handles)










% --- Executes on selection change in analysisObjectsList.
function analysisObjectsList_Callback(hObject, eventdata, handles)
% hObject    handle to analysisObjectsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns analysisObjectsList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from analysisObjectsList


%% update selection listbox

%set the selection to 1
set(handles.selectionObjectsList,'Value',1);

handles.selection = [];
currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);


for i=1:length(handles.obj.objects{currentObj}.selection)
    handles.selection{i} = handles.obj.objects{currentObj}.selection{i}.name;
end
set(handles.selectionObjectsList,'String',handles.selection);

guidata(hObject,handles);



%update analysis listbox

currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);

currentSelection = get(handles.selectionObjectsList,'Value');


handles.analysis = [];


for i=1:length(handles.obj.objects{currentObj}.selection{currentSelection}.analysis)
    try
        handles.analysis{i} = handles.obj.objects{currentObj}.selection{currentSelection}.analysis{i}.name;
    catch
        handles.analysis{1} = 'no analysis available';
    end
end

set(handles.analysisList,'Value',1);
set(handles.analysisList,'String',handles.analysis);


redrawObjectAxis(handles);



% --- Executes during object creation, after setting all properties.
function analysisObjectsList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to analysisObjectsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in selectionObjectsList.
function selectionObjectsList_Callback(hObject, eventdata, handles)
% hObject    handle to selectionObjectsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns selectionObjectsList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from selectionObjectsList



%update analysis listbox

currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);

currentSelection = get(handles.selectionObjectsList,'Value');


handles.analysis = [];


for i=1:length(handles.obj.objects{currentObj}.selection{currentSelection}.analysis)
    try
        handles.analysis{i} = handles.obj.objects{currentObj}.selection{currentSelection}.analysis{i}.name;
    catch
        handles.analysis{1} = 'no analysis available';
    end
end

set(handles.analysisList,'Value',1);
set(handles.analysisList,'String',handles.analysis);





guidata(hObject,handles);


redrawObjectAxis(handles);





% --- Executes during object creation, after setting all properties.
function selectionObjectsList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selectionObjectsList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in analysisList.
function analysisList_Callback(hObject, eventdata, handles)
% hObject    handle to analysisList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns analysisList contents as cell array
%        contents{get(hObject,'Value')} returns selected item from analysisList


currentObj = get(handles.analysisObjectsList,'Value');
currentSelection = get(handles.selectionObjectsList,'Value');












% --- Executes during object creation, after setting all properties.
function analysisList_CreateFcn(hObject, eventdata, handles)
% hObject    handle to analysisList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in selectionMode.
function selectionMode_Callback(hObject, eventdata, handles)
% hObject    handle to selectionMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of selectionMode

guidata(hObject,handles);

redrawObjectAxis(handles);




% --- Executes on button press in createSelectionObject.
function createSelectionObject_Callback(hObject, eventdata, handles)


selectedObjects = get(handles.analysisObjectsList,'Value');

%numobjects = length(handles.obj.objects) + 1;






if length(selectedObjects) == 1
    %create selection vertex list if object is not a compound object
    
    %need to offset brushed vertex indices
    
    answer = inputdlg('name selection object');
    selectionName = answer{1};
    
    
    hBrushLine = findall(gca,'tag','Brushing');
    brushedData = get(hBrushLine, {'Xdata','Ydata','Zdata'});

    try
        brushedIdx = ~isnan(brushedData{1});
    catch
        brushedIdx = 1:length(handles.grid(:,1));
    end
    
    numselection = length(handles.obj.objects{selectedObjects}.selection)+1;
    
    
    verts = unique(handles.obj.objects{selectedObjects}.vertices);
    
    brushedIdx = find(brushedIdx)';
    
    for idx=1:length(brushedIdx)
        
        brushedIdx(idx) = verts(brushedIdx(idx));
        
        
    end
    
    %brushedIdx = handles.obj.objects{selectedObjects}.vertices(brushedIdx,:);
    
    %brushedIdx = unique(brushedIdx)
    
    
    
    handles.obj.objects{selectedObjects}.selection{numselection}.vertices = brushedIdx;
    
    
    handles.obj.objects{selectedObjects}.selection{numselection}.analysis{1} = [];
    
    
    
    handles.obj.objects{selectedObjects}.selection{numselection}.name = selectionName;
    
else
    
    %create new compound object if all objects have same dimensionality
    numObj = length(handles.obj.objects)+1;
    
    verts = [];
    
    for i=1:length(selectedObjects)
        verts = [verts; handles.obj.objects{selectedObjects(i)}.vertices];
        
    end
    
    switch size(verts,2)
        
        case 1
            type = 'pc';
        case 2
            type = 'lc';
        case 3
            type = 'fc';
    end
    
    
    handles.obj.objects{numObj}.vertices = verts;
    handles.obj.objects{numObj}.type = type;
    
    handles.obj.objects{numObj}.selection{1}.vertices = unique(verts);
    handles.obj.objects{numObj}.selection{1}.name = 'all';
    handles.obj.objects{numObj}.selection{1}.analysis{1} = [];
    
end



currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);






%update the object listbox
for i=1:length(handles.obj.objects)
    
    try
        switch handles.obj.objects{i}.type
        
            case 'p'
                tagStr = 'points ';
                
            case 'l'
                tagStr = 'line ';
                
            case 'f'
                tagStr = 'boundary ';
                
            case 'pc'
                tagStr= 'point compound';
                
            case 'lc'
                tagStr = 'line compound';
                
            case 'fc' 
                tagStr = 'boundary compound';
                
        end
        
    end
    
    handles.objects{i} = [tagStr num2str(i)];
end
set(handles.analysisObjectsList,'String',handles.objects);

set(handles.analysisObjectsList,'Value',length(handles.obj.objects));






handles.selection =[];
for i=1:length(handles.obj.objects{currentObj}.selection)
    handles.selection{i} = handles.obj.objects{currentObj}.selection{i}.name;
end
set(handles.selectionObjectsList,'String',handles.selection);


guidata(hObject,handles);








% --- Executes on button press in tessellate.
function tessellate_Callback(hObject, eventdata, handles)
% hObject    handle to tessellate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% size of computation blocks. more memory, larger blocks
BLOCKSIZE = 40000;
PRISMTHICKNESS = 0.5;
ATOMICDENSITY = 1/50; %just for test purposes


%% vertex assign and slicing
vertexList = calculateVertexList(handles);
handles.vertexList = vertexList;

handles.slicedVAP = vertexassign_v5(handles.posFile,vertexList,BLOCKSIZE);

%% calculation of prism-approximation area

for i=1:length(handles.vertexList)
    %handles.vertexList(i,8)
    A = prismArea(handles.slicedVAP{i}, ATOMICDENSITY ,PRISMTHICKNESS, 2)
    handles.vertexList(i,9) = A;
    
end









set(handles.messages,'String','posfile has been tessellated');


%for i=1:length(handles.slicedVAP)
%    len=size(handles.slicedVAP{i},1)
%end


guidata(hObject,handles);







% --- Executes on button press in ghostMode.
function ghostMode_Callback(hObject, eventdata, handles)
% hObject    handle to ghostMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ghostMode


% --- Executes on button press in pseudoConcentationProfile.
function pseudoConcentationProfile_Callback(hObject, eventdata, handles)
% hObject    handle to pseudoConcentationProfile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in openXRNG.
function openXRNG_Callback(hObject, eventdata, handles)
% hObject    handle to openXRNG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



%% load the xrng
[file path] = uigetfile({'*.xrng';'*.XRNG'},'open XRNG file');

fileName = [path file];

handles.xrng = xml_load(fileName);



%% update the elements listbox
handles.usedElements = [];

numrng = length(handles.xrng.ranges);
k = 1;

for rng=1:numrng
    
    numions = length(handles.xrng.ranges{rng}.ions);
    
    for ion = 1:numions
        
        numatoms = length(handles.xrng.ranges{rng}.ions{ion}.atoms);
        
        for atom = 1:numatoms
            
            handles.usedElements(k) = str2num(handles.xrng.ranges{rng}.ions{ion}.atoms{atom}.atomicnumber);
            k=k+1;
        end
        
        
    end
    
    
    
end


handles.usedElements = sort(unique(handles.usedElements));


for i=1:length(handles.usedElements)
    elementsStr{i} = sym4number(handles.usedElements(i));
end


set(handles.elements,'String',elementsStr);
set(handles.elements,'Max',k);





set(handles.messages,'String',[file ' loaded']);
guidata(hObject,handles);






% --- Executes on button press in proxigram.
function proxigram_Callback(hObject, eventdata, handles)
% hObject    handle to proxigram (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



%% check if we have all information

%bindist

%vap - file

%xrng file

%only one object selected!

bindist  = str2double(get(handles.binValue,'String'));

currentObj = get(handles.analysisObjectsList,'Value');
currentSelection = get(handles.selectionObjectsList,'Value');

if isempty(handles.obj.objects{currentObj}.selection{currentSelection}.analysis{1})
    numAnalysis = 1;
else
    numAnalysis = length(handles.obj.objects{currentObj}.selection{currentSelection}.analysis) + 1;
end

vertexList = handles.obj.objects{currentObj}.selection{currentSelection}.vertices;



type = handles.obj.objects{currentObj}.type;
switch type
    case {'p','pc'}
        dimension = 0;
    case {'l','lc'}
        dimension = 1;
    case {'f','fc'}
        dimension = 2;
end

%% calculate proxigram
proxi = advancedProxigram(handles.slicedVAP,handles.xrng,bindist,dimension,vertexList);


handles.obj.objects{currentObj}.selection{currentSelection}.analysis{numAnalysis}.data = proxi;
handles.obj.objects{currentObj}.selection{currentSelection}.analysis{numAnalysis}.type = 'proxigram';
handles.obj.objects{currentObj}.selection{currentSelection}.analysis{numAnalysis}.name = ['proxigram ' num2str(bindist) 'nm'];



set(handles.messages,'String',['proxigram with ' num2str(bindist) ' nm binning calculated']);

%% update analysis listbox
currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);

currentSelection = get(handles.selectionObjectsList,'Value');


handles.analysis = [];


for i=1:length(handles.obj.objects{currentObj}.selection{currentSelection}.analysis)
    try
        handles.analysis{i} = handles.obj.objects{currentObj}.selection{currentSelection}.analysis{i}.name;
    catch
        handles.analysis{1} = 'no analysis available';
    end
end

set(handles.analysisList,'String',handles.analysis);


guidata(hObject,handles);







% --- Executes on button press in IEmap.
function IEmap_Callback(hObject, eventdata, handles)
% hObject    handle to IEmap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





%bindist

%vap - file

%xrng file

%only one object selected!


prismApproxDist  = str2double(get(handles.binValue,'String'));


currentObj = get(handles.analysisObjectsList,'Value');
currentSelection = get(handles.selectionObjectsList,'Value');

if isempty(handles.obj.objects{currentObj}.selection{currentSelection}.analysis{1})
    numAnalysis = 1;
else
    numAnalysis = length(handles.obj.objects{currentObj}.selection{currentSelection}.analysis) + 1;
end

vertexList = handles.obj.objects{currentObj}.selection{currentSelection}.vertices;



type = handles.obj.objects{currentObj}.type;
switch type
    case {'p','pc'}
        dimension = 0;
    case {'l','lc'}
        dimension = 1;
    case {'f','fc'}
        dimension = 2;
end



%% calculate IE map
area = handles.vertexList(:,9)
area = ones(length(area),1);

excess = featureExcess(handles.slicedVAP,handles.xrng,dimension,vertexList,area);




handles.obj.objects{currentObj}.selection{currentSelection}.analysis{numAnalysis}.data = excess;
handles.obj.objects{currentObj}.selection{currentSelection}.analysis{numAnalysis}.type = 'IEmap';
handles.obj.objects{currentObj}.selection{currentSelection}.analysis{numAnalysis}.name = 'IE map';


set(handles.messages,'String','Interfacial excess map calculated');





%% update analysis listbox
currentObj = get(handles.analysisObjectsList,'Value');
currentObj = currentObj(1);

currentSelection = get(handles.selectionObjectsList,'Value');


handles.analysis = [];


for i=1:length(handles.obj.objects{currentObj}.selection{currentSelection}.analysis)
    try
        handles.analysis{i} = handles.obj.objects{currentObj}.selection{currentSelection}.analysis{i}.name;
    catch
        handles.analysis{1} = 'no analysis available';
    end
end

set(handles.analysisList,'String',handles.analysis);


guidata(hObject,handles);





% --- Executes on button press in deleteAnalysis.
function deleteAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to deleteAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in deleteSelection.
function deleteSelection_Callback(hObject, eventdata, handles)
% hObject    handle to deleteSelection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in loadAnalysis.
function loadAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to loadAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in saveAnalysis.
function saveAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to saveAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function binValue_Callback(hObject, eventdata, handles)
% hObject    handle to binValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of binValue as text
%        str2double(get(hObject,'String')) returns contents of binValue as a double


% --- Executes during object creation, after setting all properties.
function binValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to binValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in elements.
function elements_Callback(hObject, eventdata, handles)
% hObject    handle to elements (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns elements contents as cell array
%        contents{get(hObject,'Value')} returns selected item from elements


% --- Executes during object creation, after setting all properties.
function elements_CreateFcn(hObject, eventdata, handles)
% hObject    handle to elements (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in rorate3D.
function rorate3D_Callback(hObject, eventdata, handles)
% hObject    handle to rorate3D (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rotate3d;

% --- Executes on button press in zoom.
function zoom_Callback(hObject, eventdata, handles)
% hObject    handle to zoom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
zoom;

% --- Executes on button press in brush.
function brush_Callback(hObject, eventdata, handles)
% hObject    handle to brush (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

brush on;


% --- Executes on button press in deleteVerts.
function deleteVerts_Callback(hObject, eventdata, handles)
% hObject    handle to deleteVerts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in displayAtoms.
function displayAtoms_Callback(hObject, eventdata, handles)
% hObject    handle to displayAtoms (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of displayAtoms


% --- Executes on button press in displyNormals.
function displyNormals_Callback(hObject, eventdata, handles)
% hObject    handle to displyNormals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of displyNormals


% --- Executes on button press in IEvalue.
function IEvalue_Callback(hObject, eventdata, handles)
% hObject    handle to IEvalue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in createFigure.
function createFigure_Callback(hObject, eventdata, handles)
% hObject    handle to createFigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% obj.objects{i}    
    % .type (p,l,f,c,v) c = compound v = volume
    % .vertices
    % .selection
        % .vertices
        % .analysis{}
            % .name
            % .type (enum in 'IEmap','proxigram','IEval','concShell','bulkConc')
            % .data

currentObj = get(handles.analysisObjectsList,'Value');
currentSelection = get(handles.selectionObjectsList,'Value');
currentAnalysis = get(handles.analysisList,'Value');


currentElements = get(handles.elements,'Value');


for i=1:length(currentElements)
    elementDialog{i} = sym4number(handles.usedElements(currentElements(i)));
    currentElements(i) = handles.usedElements(currentElements(i));
    defaultAnswer{i} = '1';
    
end


type = handles.obj.objects{currentObj}.selection{currentSelection}.analysis{currentAnalysis}.type;



switch handles.obj.objects{currentObj}.type
    case {'p','pc'}
        dimension = 0;
    case {'l','lc'}
        dimension = 1;
    case {'f','fc'}
        dimension = 2;
end



%% choose the plotting type
switch type
    case 'proxigram'
        
        
        %disp('plotting proxigram');
        if ~(length(currentElements)==1)
            factors = inputdlg(elementDialog,'plotting factors',1,defaultAnswer);
        
            for fac=1:length(factors)
                plotFactors(fac) = str2num(factors{fac});
            end
        else
            plotFactors = 1;
        end
        
        figure('Name','proxigram','NumberTitle','off')
        plotProxigram(currentElements, handles.obj.objects{currentObj}.selection{currentSelection}.analysis{currentAnalysis}.data,plotFactors);
        
        
    case 'IEmap'
        %disp('plotting IE map');
        
        excess = handles.obj.objects{currentObj}.selection{currentSelection}.analysis{currentAnalysis}.data;
        verts = handles.obj.vertices;
        triangulation = handles.obj.objects{currentObj}.vertices;
        
        if ~(length(currentElements)==1)
            factors = inputdlg(elementDialog,'plotting factors',1,defaultAnswer);
        
            for fac=1:length(factors)
                plotFactors(fac) = str2num(factors{fac});
            end
        else
            plotFactors = 1;
        end
        
        figure('Name','IEmap','NumberTitle','off')
        plotFeatureExcess(verts,excess,currentElements,dimension,triangulation,plotFactors);
end











% --- Executes on button press in exportXLS.
function exportXLS_Callback(hObject, eventdata, handles)
% hObject    handle to exportXLS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in bulkConc.
function bulkConc_Callback(hObject, eventdata, handles)
% hObject    handle to bulkConc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




function redrawObjectAxis(handles)
% ghostmode: all objects are displayed, the selected ones solid, the rest
% semitransparent


% selection mode: the primary selected object will be displayed as
% scatterplot, selected elements will create a new selection object
selectionMode = get(handles.selectionMode,'Value');




set(gcf,'CurrentAxes',handles.objectAxis);
cla;

rotate3d on
hold on

markerSize = 5;
atomSize = 10;
faceAlpha = 0.2;


numobjects = length(handles.obj.objects);
selectedelements = get(handles.analysisObjectsList,'Value');




%only display selection if only one object is selected
dispSelection = length(selectedelements) == 1;



if dispSelection
    selectionObj = get(handles.selectionObjectsList,'Value');
    
    selectionVerts = handles.obj.objects{selectedelements}.selection{selectionObj}.vertices;
    
    
    % creating one vertex list with selected verts, one with unselected
    
    
    objVerts = handles.obj.objects{selectedelements}.vertices;
    
    
    isSelected = objVerts == selectionVerts(1);
    
    for sel=2:length(selectionVerts)
        
       isSelected = isSelected + (objVerts == selectionVerts(sel)); 
        
        
    end
    
    
    switch handles.obj.objects{selectedelements}.type
        case {'p','pc'}
            dimension = 0;
        case {'l','lc'}
            dimension = 1;
        case {'f','fc'}
            dimension = 2;
    end
    
    
    isSelected = sum(isSelected,2) == (dimension+1);
    
    
    selectedNgon = handles.obj.objects{selectedelements}.vertices(isSelected,:);
    unselectedNgon = handles.obj.objects{selectedelements}.vertices(~isSelected,:);
    
    
    
end


if selectionMode
    selectedelements = selectedelements(1);
    
    
end


for k=1:length(selectedelements)
    
    i = selectedelements(k);
    
    type = handles.obj.objects{i}.type;
    
    if selectionMode
        type = 'sel';
    end
    
    
    
    
    switch type
        case {'p','pc'}
            
            
            
            if ~dispSelection
                scatter3(handles.obj.vertices(handles.obj.objects{i}.vertices(:,1),1),    handles.obj.vertices(handles.obj.objects{i}.vertices(:,1),2),    handles.obj.vertices(handles.obj.objects{i}.vertices(:,1),3),'r','MarkerFaceColor','r');
                
                
                
                
            else
                scatter3(handles.obj.vertices(selectedNgon,1),    handles.obj.vertices(selectedNgon,2),    handles.obj.vertices(selectedNgon,3),'r','MarkerFaceColor','r');
                if ~isempty(unselectedNgon)
                    scatter3(handles.obj.vertices(unselectedNgon,1),    handles.obj.vertices(unselectedNgon,2),    handles.obj.vertices(unselectedNgon,3),'r');
                end
            end
            
            
            
            
            
            
        case {'l','lc'}
            
            
            
            if ~dispSelection
                verts = [handles.obj.objects{i}.vertices(:,1); handles.obj.objects{i}.vertices(end,2)];
                
                plot3(handles.obj.vertices(verts,1),    handles.obj.vertices(verts,2),    handles.obj.vertices(verts,3),'-go','MarkerFaceColor','g','LineWidth',3);
                
                
                
            else
                
                

                plot3(handles.obj.vertices(selectedNgon(:,1),1),    handles.obj.vertices(selectedNgon(:,1),2),    handles.obj.vertices(selectedNgon(:,1),3),'-go','MarkerFaceColor','g','LineWidth',3);
                % plotting endvector
                verts = handles.obj.objects{i}.vertices;
                plot3(handles.obj.vertices(verts(end,:)',1),    handles.obj.vertices(verts(end,:),2),    handles.obj.vertices(verts(end,:),3),'-r','LineWidth',2);
                scatter3(handles.obj.vertices(verts(1,1),1),    handles.obj.vertices(verts(1,1),2),    handles.obj.vertices(verts(1,1),3),'MarkerFaceColor','b','SizeData',60);

                
                
                if ~isempty(unselectedNgon)
                    
                    plot3(handles.obj.vertices(unselectedNgon(:,1),1),    handles.obj.vertices(unselectedNgon(:,1),2),    handles.obj.vertices(unselectedNgon(:,1),3),'--go','LineWidth',1);
                end
            end
            
            
            
            
            
            
        case {'f','fc'}
            
            
            if ~dispSelection
                dispPatch.vertices = handles.obj.vertices;
                dispPatch.faces = handles.obj.objects{i}.vertices;
                p(k) = patch(dispPatch);


                %shading interp;
                set(p(k),'EdgeColor','b');
                set(p(k),'FaceColor','b');
                set(p(k),'FaceAlpha',faceAlpha);
                
            else
                dispPatchSel.vertices = handles.obj.vertices;
                dispPatchUnsel.vertices = handles.obj.vertices;
                
                dispPatchSel.faces = selectedNgon;
                dispPatchUnsel.faces = unselectedNgon;
                
                selP = patch(dispPatchSel);
                set(selP,'EdgeColor','b');
                set(selP,'Marker','o');
                set(selP,'MarkerFaceColor','r');
                set(selP,'MarkerSize',markerSize);
                set(selP,'FaceColor','b');
                set(selP,'FaceAlpha',faceAlpha*2);
                
                if ~isempty(unselectedNgon)
                    unselP = patch(dispPatchUnsel);
                    set(unselP,'EdgeColor','b');
                    set(unselP,'FaceColor','b');
                    set(unselP,'FaceAlpha',faceAlpha);
                end
                
                
                
            end
            
            
        case 'sel'

            verts = unique(handles.obj.objects{i}.vertices);
            
            
            scatter3(handles.obj.vertices(verts,1),    handles.obj.vertices(verts,2),    handles.obj.vertices(verts,3),'b');

            
    end
    
    
end

axis equal











%% need to redo points and lines!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
function vertexList = calculateVertexList(handles)

numverts = size(handles.obj.vertices,1);
vertexList = [];


for i=1:length(handles.obj.objects)
    

    switch handles.obj.objects{i}.type
        
        case 'p'
            
            dimensionality = 1;
            
            usedVerts = unique(handles.obj.objects{i}.data.vertices);
            
            numUsedVerts = length(usedVerts);
            
            append = [handles.obj.vertices(usedVerts,:) repmat(i,numUsedVerts,1) ones(numUsedVerts,3) repmat(dimensionality,numUsedVerts,1) repmat(0,numUsedVerts,1)];
            
            
            
                
        case 'l'
            
            dimensionality = 2;
            
            usedVerts = unique(handles.obj.objects{i}.vertices);
            
            numUsedVerts = length(usedVerts);
            
            
            %% calculation of linevectors

            vertices = handles.obj.vertices(handles.obj.objects{i}.vertices(:,1),:);
    
            linevector = zeros(size(vertices,1),4);
    
    
                % first element of linear dislocation
            linevector(1,1:3) = (vertices(2,1:3) - vertices(1,1:3))/norm(vertices(2,1:3) - vertices(1,1:3));
    
            linevector(1,4) = norm(vertices(2,1:3) - vertices(1,1:3));
    
    
                %last element of linear dislocation
            linevector(end,1:3) = (vertices(end,1:3) - vertices(end-1,1:3))/norm(vertices(end,1:3) - vertices(end-1,1:3));
    
            linevector(end,4) = norm(vertices(end,1:3) - vertices(end-1,1:3));
    
    
                %vector1 goes from the i-1th element to the ith
            vector1 = vertices(2:end-1,1:3) - vertices(1:end-2,1:3);
             %vector2 goes from the ith element to the i+1th
            vector2 = vertices(3:end,1:3) - vertices(2:end-1,1:3);
    
                %normalize that vector
            vector = vector1+vector2;
            len = repmat( sqrt( sum( vector.^2,2)), 1,3);
    
    
            vector = vector./len;
    
                %assign
            linevector(2:end-1,1:3) = vector;
            
            
            
            
            
            
            
            append = [handles.obj.vertices(usedVerts,:) repmat(i,numUsedVerts,1) ones(numUsedVerts,3) repmat(dimensionality,numUsedVerts,1) repmat(0,numUsedVerts,1)];
            
            % need to calculate linevectors
            
            
                
        case 'f'
            
            dimensionality = 3;
            
            usedVerts = unique(handles.obj.objects{i}.vertices);
            
            usedVerts = sort(usedVerts);
            
            
            
            % need to calculate vertex normals
            patch.vertices = handles.obj.vertices(usedVerts,:);
            tris = handles.obj.objects{i}.vertices;
            for tri=1:size(tris,1)
                for col = 1:3
        
                   tris(tri,col) = usedVerts(tris(tri,col));
                end
            end
            

            patch.faces = tris;
            normals = patchnormals(patch);
            
            
            numUsedVerts = length(usedVerts);
            
            append = [handles.obj.vertices(usedVerts,:)   repmat(i,numUsedVerts,1)   normals   repmat(dimensionality,numUsedVerts,1)   repmat(0,numUsedVerts,1)];
            
            
            
           
            

        
    end
    
    vertexList = [vertexList append];
    
    
end

vertexList;




% --- Executes on button press in createVolume.
function createVolume_Callback(hObject, eventdata, handles)
% hObject    handle to createVolume (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in multicore.
function multicore_Callback(hObject, eventdata, handles)
% hObject    handle to multicore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of multicore

mc = get(hObject,'Value');

if mc
    matlabpool open
else
    matlabpool close
end
