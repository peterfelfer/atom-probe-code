function [A] = prismArea(vap, atomdens, thickness, dimensionality)

%% calculates the area around a vertex using a prism approximation. This
%% means that the area  = volume/d


switch dimensionality
    
    case 0
        
        disp('prism approx for 0D elements not implemented');
        A=2;
        
    case 1
        
        disp('prism approx for 1D elements not implemented');
        A=1;
        
        
    case 2
        
        negThick = thickness*-1;
        vap(vap(:,7) > thickness,:) = [];
        vap(vap(:,7) < negThick,:) = [];


        numatoms = length(vap);

        A = (numatoms * atomdens)/thickness;
        
        
    otherwise
        A = 1;
        disp('dimensionality undefined');
        
        
end







end