function [vapout] = vertexassign_v5(pos,verts,blocksize)

%%reads a pos file [x,y,z] converted to a Matlab variable and a vertex file
%%[x,y,z] and assigns every atom to the closest vertex.

%%FULLY VECTORIZED AND CPU PARRALELLIZED VERSION 
%%parallel session has to be open!!!!

tic;

pos = single(pos);

vertarrayc = Composite();

cores = length(vertarrayc);



len=length(pos);

vertnum = length(verts);

verts1 = verts; %because we need the vertex normals later

verts = verts(:,1:3); % only need vertex coordinates for now


vap = [pos(:,1),pos(:,2),pos(:,3),pos(:,4),zeros(len,1),(ones(len,1).*10000)];

clear pos;


%% chop VAP file into blocks roughly of size 'blocksize', under the
%% condition that it needs to be devided by the cores and into blocks.

blocks = fix(len/blocksize);

blocks = cores*(fix(blocks/cores)+1);

blocksize = fix(len/blocks)+1;

totalsize = blocksize*blocks;

postoadd = totalsize - len;

toadd = zeros(postoadd,6);

vap = [vap; toadd];


% this means we have a number of blocks that can be divided by cores

%% creating block of vertices for linear operation as composite


vertarray = zeros(blocksize,3,vertnum);

verts=verts';

for k=1:blocksize

    vertarray(k,:,:) = verts;

end


for ii=1:length(vertarrayc)
    vertarrayc{ii}=vertarray;
end

clear vertarray;


%% create a distributed array for parallell computing
disp(['assigning vertices using ', sprintf('%u',cores),' cores with a blocksize of ',sprintf('%u',blocksize)]);

distvap = Composite();

percore = totalsize/cores;

startindex=1;
for ii=1:length(distvap)
    
    %distribute datablocks
    endindex = startindex+percore-1;
    distvap{ii} = vap(startindex:endindex,:);
    startindex=startindex+percore;
    
end


clear vap;


%initialize progress bar
parfor_progress(blocks);

spmd
    
    
    for j=1:(blocks/cores)


        
        posarray = zeros(blocksize,3,vertnum);

        endindex = blocksize*j;
        startindex = endindex - blocksize +1;


        posblock = distvap(startindex:endindex,1:3);
       


        for k=1:vertnum

            posarray(:,:,k) = posblock;

        end

        %actual computation
        
        posarray = posarray - vertarrayc;

        posarray = posarray.^2;
        
        distance = sum(posarray,2);
        
        distance = squeeze(distance);

        [mindistance,minindex] = min(distance,[],2);

        distvap(startindex:endindex,5) = minindex;

        distvap(startindex:endindex,6) = sqrt(mindistance);
        
        
        %update progress bar
        parfor_progress;
        

        

    end





end

%remove progress bar file
parfor_progress(0);



vapout = zeros(totalsize,6);

block = length(distvap{1});
progressbar('copying data back');
for ii=1:length(distvap)
    vapout(block*(ii-1)+1:block*ii,:) = distvap{ii};
    
    progressbar(ii/length(distvap));
end


%remove excess elements
vapout((len+1):end,:)=[];


% calculate distances along normals/lineelements

vapout(:,7:8) = vectorDistances(vapout,verts1);


vapout = slicevap(vapout,verts1);



toc;
end











function [dist] = vectorDistances(vap,grid)

% calculates the distance of an atom along its vertexnormal and
% perpendicular to that (second column)



posingridspace = vap(:,1:3) - grid(vap(:,5),1:3);

dist(:,1) = sum(posingridspace.*grid(vap(:,5),5:7),2);

dist(:,2) = sqrt(vap(:,6).^2 - dist(:,1).^2);

dist = single(dist);

end



function sliced = slicevap(vap,verts)

% returns a cell array of vaps for further analysis


verts = size(verts,1);
assignedvertices = vap(:,5);
sliced = cell(verts,1);

progressbar('slicing vertex assigned posfile');

for i=1:verts
    sliced{i} = vap(assignedvertices == i ,:);
    progressbar(i/verts);
end

end






  





%Copyright (c) 2011, Jeremy Scheff
%All rights reserved.

%Redistribution and use in source and binary forms, with or without 
%modification, are permitted provided that the following conditions are 
%met:
%
%    * Redistributions of source code must retain the above copyright 
%      notice, this list of conditions and the following disclaimer.
%    * Redistributions in binary form must reproduce the above copyright 
%      notice, this list of conditions and the following disclaimer in 
%      the documentation and/or other materials provided with the distribution
%      
%THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
%AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
%IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
%ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
%LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
%CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
%SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
%INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
%CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
%ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
%POSSIBILITY OF SUCH DAMAGE.






function percent = parfor_progress(N)
%PARFOR_PROGRESS Progress monitor (progress bar) that works with parfor.
%   PARFOR_PROGRESS works by creating a file called parfor_progress.txt in
%   your working directory, and then keeping track of the parfor loop's
%   progress within that file. This workaround is necessary because parfor
%   workers cannot communicate with one another so there is no simple way
%   to know which iterations have finished and which haven't.
%
%   PARFOR_PROGRESS(N) initializes the progress monitor for a set of N
%   upcoming calculations.
%
%   PARFOR_PROGRESS updates the progress inside your parfor loop and
%   displays an updated progress bar.
%
%   PARFOR_PROGRESS(0) deletes parfor_progress.txt and finalizes progress
%   bar.
%
%   To suppress output from any of these functions, just ask for a return
%   variable from the function calls, like PERCENT = PARFOR_PROGRESS which
%   returns the percentage of completion.
%
%   Example:
%
%      N = 100;
%      parfor_progress(N);
%      parfor i=1:N
%         pause(rand); % Replace with real code
%         parfor_progress;
%      end
%      parfor_progress(0);
%
%   See also PARFOR.

% By Jeremy Scheff - jdscheff@gmail.com - http://www.jeremyscheff.com/

error(nargchk(0, 1, nargin, 'struct'));

if nargin < 1
    N = -1;
end

percent = 0;
w = 50; % Width of progress bar

if N > 0
    f = fopen('parfor_progress.txt', 'w');
    if f<0
        error('Do you have write permissions for %s?', pwd);
    end
    fprintf(f, '%d\n', N); % Save N at the top of progress.txt
    fclose(f);
    
    if nargout == 0
        disp(['  0%[>', repmat(' ', 1, w), ']']);
    end
elseif N == 0
    delete('parfor_progress.txt');
    percent = 100;
    
    if nargout == 0
        disp([repmat(char(8), 1, (w+9)), char(10), '100%[', repmat('=', 1, w+1), ']']);
    end
else
    if ~exist('parfor_progress.txt', 'file')
        error('parfor_progress.txt not found. Run PARFOR_PROGRESS(N) before PARFOR_PROGRESS to initialize parfor_progress.txt.');
    end
    
    f = fopen('parfor_progress.txt', 'a');
    fprintf(f, '1\n');
    fclose(f);
    
    f = fopen('parfor_progress.txt', 'r');
    progress = fscanf(f, '%d');
    fclose(f);
    percent = (length(progress)-1)/progress(1)*100;
    
    if nargout == 0
        perc = sprintf('%3.0f%%', percent); % 4 characters wide, percentage
        disp([repmat(char(8), 1, (w+9)), char(10), perc, '[', repmat('=', 1, round(percent*w/100)), '>', repmat(' ', 1, w - round(percent*w/100)), ']']);
    end
end

end
