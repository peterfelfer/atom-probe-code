function rangefile = addRange(rangefile, mcbegin, mcend, atoms, hitmulti)
%ion is taken as a matrix of pairs of atomic numbers and isotope numbers. 0
%for the isotope can be chosen if no deconvolution is used.

% the variable rangefile is ment to be saved as an XML.


rangefile.version = '0.1';

    
numrng = length(rangefile.ranges) +1;
    




rangefile.ranges{numrng}.masstochargebegin = num2str(mcbegin,5);
rangefile.ranges{numrng}.masstochargeend = num2str(mcend,5);

numatoms = size(atoms,1);


volume = 0;
weight = 0;

for i=1:numatoms
    rangefile.ranges{numrng}.ions{1}.atoms{i}.atomicnumber = int2str(atoms(i,1));
    rangefile.ranges{numrng}.ions{1}.atoms{i}.isotope = int2str(atoms(i,2));
    volume = volume + atomicvolume(atoms(i,1));
    weight = weight + isotopicWeight(atoms(i,1),atoms(i,2));
end



rangefile.ranges{numrng}.ions{1}.volume = num2str(volume,5);

rangefile.ranges{numrng}.ions{1}.chargestate = int2str(round(weight/mcbegin));




if exist('hitmulti','var')
    rangefile.ranges.hitmultiplicity = int2str(hitmulti);
end



ranges = zeros(numrng,2);
for i=1:numrng
    ranges(i,1) = str2double(rangefile.ranges{i}.masstochargebegin);
    ranges(i,2) = str2double(rangefile.ranges{i}.masstochargeend);
    
end
    

% checks for overlapping ranges
checkranges = sortrows(ranges,1);

if sum(~(checkranges(1:end-1,2)<=checkranges(2:end,1)))
    disp('This range overlaps with another range');
end





end